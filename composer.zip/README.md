# jewelry_shop
Project website jewelry shop use PHP, MVC, PDO ( MySQL)
