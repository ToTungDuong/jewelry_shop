
<img style = "width : 100%; height : 100vh;" src="public/template_jewelry_shop/img/404.webp" alt="">
