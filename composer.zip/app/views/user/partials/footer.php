<footer class="py-5 bg_2">
      <div class="container">
        <div class="row">
          <div class="col-lg-3">
            <img src="public/template_jewelry_shop/img/logo.png" alt="" />
          </div>
          <div class="col-lg-3">
            <h5 class="fw-bold">Contact Us</h5>
            <p>TEXT: (090) 123-EIIA</p>
            <p>Email:example@domain.com</p>
          </div>
          <div class="col-lg-3">
            <h5 class="fw-bold">Address</h5>
            <p>685 Market Street San Francisco, CA 94105, US</p>
          </div>
          <div class="col-lg-3">
            <h5 class="fw-bold">Social Newwork</h5>
            <ul class="d-flex">
              <li class="list-unstyled px-1">
                <a href=""><img src="../img/ings.png" alt="" /></a>
              </li>
              <li class="list-unstyled px-1">
                <a href=""><img src="../img/fb.png" alt="" /></a>
              </li>
              <li class="list-unstyled px-1">
                <a href=""><img src="../img/twiter.png" alt="" /></a>
              </li>
            </ul>
          </div>
        </div>
      </div>
</footer>